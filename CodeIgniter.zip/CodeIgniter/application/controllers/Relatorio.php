<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Relatorio extends CI_Controller {

	public function index()
	{
		$this->load->view('pagina_inicial');
	}
	
	public function relatorio(){
		$data['x']=$this->db->get('citacoes')->result();
		$this->load->view('relatorio', $data);
	}
	
	public function cadastro()
	{
		$this->load->view('cadastro');
	}
	public function adicionar(){
		$info['nomeArquivo']=$this->input->post ('txt_titulo');
		$info ['titulo']=$this->input->post('txt_texto');
		$info['autores']=$this->input->post('txt_titulo');
		$info ['citacoes']=$this->input->post('txt_texto');
		$info['referencias']=$this->input->post('txt_titulo');
		$info ['dataCadastro']=$this->input->post('txt_texto');
		$info['palavrasChave']=$this->input->post('txt_titulo');
		
		if($this->db->insert('citacoes',$info)){
			redirect(base_url());
		}else{
			echo "Não foi possível gravar a postagem no banco de dados";
		}
	}
}
