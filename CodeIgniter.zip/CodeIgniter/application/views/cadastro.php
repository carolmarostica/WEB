<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
	<meta charset="utf-8">
	<title>Página Inicial</title>	
</head>
<body>
<?php
	echo anchor(base_url(), "Página Inicial");
	echo form_open( base_url('relatorio/adicionar')) .	
	form_label("  :"," txt_titulo") . br().
	form_input('txt_titulo') . br () .
	form_label(" Título :"," txt_titulo") . br().
	form_input('txt_titulo') . br () .
	form_label(" Título :"," txt_titulo") . br().
	form_input('txt_titulo') . br () .
	form_label(" Título :"," txt_titulo") . br().
	form_input('txt_titulo') . br () .
	form_label(" Título :"," txt_titulo") . br().
	form_input('txt_titulo') . br () .
	form_label(" Título :"," txt_titulo") . br().
	form_input('txt_titulo') . br () .
	form_label(" Título :"," txt_titulo") . br().
	form_input('txt_titulo') . br () .
	form_label("Texto :"," txt_texto") . br() .
	form_textarea('txt_texto') . br() .
	form_submit(" btn_enviar", "Enviar Dados") .
	form_close() ;
?>
</body>
</html>

