<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Página Inicial</title>	
</head>
<body>
<h2>Menu</h2>
<?php
	echo anchor(base_url(), "Págia Inicial") .br()
	.anchor(base_url("Relatorio/cadastro"),"Cadastrar Nova Referência").br()
	.anchor(base_url("relatorio"),"Listagem das Referências Cadastradas").br()
	.anchor(base_url(),"Consula Referências") ;
?>

</body>
</html>
