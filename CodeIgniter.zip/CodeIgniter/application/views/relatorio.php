<?php
defined('BASEPATH') OR exit('No direct script access allowed');

	foreach( $x as $texto ) {
	echo "<h3>".$texto->nomeArquivo."</h3>";
	echo "<p>".$texto->titulo."</p>";
	echo "<p>".$texto->texto."</p>";
	echo "<hr>";
 }
?>
