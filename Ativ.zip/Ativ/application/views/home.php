<div id="homebody">	
<div class="alinhado-centro borda-base espaco-vertical">
<h3> Seja Bem-Vindo ao nosso site! </h3>
<br>
<p> Cadastramos, excluimos, atualizamos e consultamos seus pokemons! Faça login e participe de nosso site. </p>
<?php echo anchor(base_url("login") ,"Login") ?> 
</div>

