<div class="container">
	<div class="masthead">
		<img src="<? echo base_url('../../assets/img/logo.png')?>"> 
		<?php echo heading('Pokemon GO' ,3 ,'class="muted" '); ?>
			<ul class ="nav nav-tabs" >
			<li class ="active"><?php echo anchor(base_url() ,"Home") ?></li>
			<li><?php echo anchor(base_url("login") ,"Login") ?></li>
			<li><?php echo anchor(base_url("cadastrop") ,"Cadastro de Pokemon") ?></li>
			<li><?php echo anchor(base_url("busca") ,"Busca") ?></li>
</ul>
</div>
