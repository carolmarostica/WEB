<div class="conteudo">

	<img src="img3.jpg">
	<div class="textoSobre">
		<h1>Sobre a Empresa</h1>
		<h5 class="text-justify">Temos o objetivos de aumentar o número de usuários de transportes sustentáveis. Através da nossa proposta reforçamos a importância de cuidar do meio ambiente.</h5>
		<h5>O aluguel das bicicletas pode ser feito em qualquer ponto <i>CicleBike</i> e pode ser devolvido em outro ponto, porém para alugar a bike é importânte que o usuário seja
		cadastrado em nosso sistema como cliente. </h5>
		<h4>Desapegue do seu carro!</h4>
	</div>      
    
</div>
