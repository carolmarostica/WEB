<div id="homebody">	
	<div class="alinhado-centro espaco-vertical">
		<h3>Buscar</h3>
		<br>
		<?php
			echo form_open( base_url(), array('id'=>'form_pesquisa')) . 
			"<div class='alinhado-centro espaco-vertical'>" .
				form_input( array('id'=>'pesq','pesq'=>'pesq','Placeholder'=>'Pesquisar', 'value'=>set_value('pesq')) ) .
				form_submit('btn_pesq','Pesquisar') .
			"</div>" .
			form_close() ; ?>
	</div>
</div>

