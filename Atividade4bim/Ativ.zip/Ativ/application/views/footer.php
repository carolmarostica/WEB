	<hr>
	<div class="alinhado-centro">
		<img src="http://localhost/Ativ/assets/img/agua.jpg" class="ft">
		<img src="http://localhost/Ativ/assets/img/bubasalro.jpg" class="ft">
		<img src="http://localhost/Ativ/assets/img/patinho.jpg" class="ft">
		<img src="http://localhost/Ativ/assets/img/pikachu.png" class="ft">
		<img src="http://localhost/Ativ/assets/img/charmander.jpg" class="ft">
		<img src="http://localhost/Ativ/assets/img/minhoca.jpg" class="ft">
		<img src="http://localhost/Ativ/assets/img/ovo.png" class="ft">
	</div>
	<div id ="footer" class="borda-topo espaco-vertical alinhado-centro">
	&copy; <?php echo date("Y") ; ?>-Todos os direitos reservados.
	</div>
</div>
