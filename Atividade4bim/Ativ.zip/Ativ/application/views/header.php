<div class="container">
	<div class="masthead">
		<img src="http://localhost/Ativ/assets/img/logo.png" class="logo">
		<br>
		<h3>Pokemon GO</h3>
		<br>
		<ul class ="nav nav-tabs" >
			<li class ="active"><?php echo anchor(base_url() ,"Home") ?></li>
			<li><a href='http://localhost/Ativ/index.php/Login'>Login</a><li>
			<li><a href='http://localhost/Ativ/index.php/Consulta'>Consulta</a><li>
			<li><a href='http://localhost/Ativ/index.php/Buscar'>Buscar</a><li>
		</ul>
	</div>
