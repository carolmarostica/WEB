<div id="homebody">	
	<div class="alinhado-centro espaco-vertical">
		<h3>Cadastro de Pokemon</h3>
		<br>
		
		<img src="http://localhost/Ativ/assets/img/pokebola.jpg" id="ft">
		<table width="80%" border="1" class="tabela">
    		<thead>
      		<tr>
        			<th class="alinhado-centro">Nome</th>
        			<th class="alinhado-centro">Tipo do Pokémon</th>
        			<th class="alinhado-centro">Data de Captura</th>
        			<th class="alinhado-centro">Ações</th>
     			</tr>
    		</thead>
    		<tbody>
				<tr>
					<?php
              			foreach($pokemon as $poquemon){
               				echo "<tr>";
                 			echo "<td>".$poquemon->Nome."</td>";
                 			echo "<td>".$poquemon->Tipo_Pokemon."</td>";
                 			$dh = explode(" ", $poquemon->Data_Captura);
                 			$data = explode("-", $dh[0]);                 			
                  			echo "<td>".$data[2]."/".$data[1]."/".$data[0]."</td>";
                 			echo "<td>". "<img class='acao' src='http://localhost/Ativ/assets/img/atualizar.png'>". "<img src='http://localhost/Ativ/assets/img/deletar.png' class='acao'>"  ."</td>";
              			}
               		?>
           		</tr>
         	</tbody>
      </table>
			
	</div>
	</div>

