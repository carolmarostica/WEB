<div id="homebody">	
	<div class="alinhado-centro espaco-vertical">
		<h3> Seja Bem-Vindo ao nosso site! </h3>
		<br><br>
		<p> Cadastramos, excluimos, atualizamos e consultamos seus pokemons! Faça login e participe de nosso site. </p>
		<a href='http://localhost/Ativ/index.php/Login'>Login</a>
	</div>
</div>
