<div id="homebody">	
	<div class="alinhado-centro espaco-vertical">
		<h3>Login</h3>
		<br>
		<?php echo validation_errors() ;
			echo form_open( base_url('login/adicionar'), array('id'=>'form_cadastro')) . 
			"<div class='alinhado-centro espaco-vertical'>" .
				form_input( array('id'=>'nome','name'=>'nome','Placeholder'=>'Login', 'value'=>set_value('nome')) ) .
				form_password( array('id'=>'senha','name'=>'senha','Placeholder'=>'Senha','value'=> set_value('senha'))) . 
				form_submit('btn_entrar','Entrar') .
			"</div>" .
			form_close() ; ?>
	</div>
</div>

