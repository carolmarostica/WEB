<?php defined('BASEPATH') OR exit('No direct script access allowed');
	class Consulta extends CI_Controller{
		private $pokemon;
		public function __construct(){
			parent::__construct();
			$this->load->model("Pokemonmodel", "pmodel");
			$this->pokemon = $this->pmodel->listar();
		}

		public function index(){
			$this->load->view('html-header');
			$this->load->view('header');	
			$info['pokemon'] = $this->pokemon;	
			$this->load->view('consulta', $info);	
			$this->load->view('footer');
			$this->load->view('html-footer');
		}
	}
?>
