	<div id ="footer" class ="borda-topo espaco-vertical alinhado-centro">
		&copy; <?php echo date("Y"); ?> -Todos os direitos reservados.
	</div>
</div>
